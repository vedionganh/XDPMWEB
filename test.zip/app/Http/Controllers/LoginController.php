<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
use Illuminate\Support\Facades\Redirect;
session_start();
class LoginController extends Controller
{
    public function login()
    {
         $cate_product=DB::table('category')->where('trangthai','0')->orderby('danhmuc_id','desc')->get();



        return view('pages.Thanhtoan.login_check')->with('category', $cate_product);

    }
    public function dangkikh(Request $request){
        $data=array();
        $data['tenkh']=$request->tenkh;
        $data['email']=$request->em;
        $data['matkhau']=md5($request->mk);
        $data['sdt']=$request->ph;
        $khachhang_id=DB::table('khachhang')->insertGetId($data);
        Session::put('khachhang_id',$khachhang_id);
         Session::put('tenkh',$request->tenkh);
        return redirect::to('/thanh-toan');
    }

    public function thanhtoan(){

         $cate_product=DB::table('category')->where('trangthai','0')->orderby('danhmuc_id','desc')->get();
        return view('pages.Thanhtoan.thanhtoan')->with('category', $cate_product);

    }
    public function luuthanhtoan(Request $request)
    {
        $data=array();
        $data['ten_ttkh']=$request->ten_ttkh;
        $data['email_ttkh']=$request->email_ttkh;
        $data['diachi']=$request->diachi;
            $data['sdt_ttkh']=$request->sdt_ttkh;
        $data['ghichu']=$request->ghichu;

        $ttkh_id=DB::table('ttkh')->insertGetId($data);
        Session::put('ttkh_id',$ttkh_id);

        return redirect::to('/chonthanhtoan');
    }
    public function chonthanhtoan()
    {

    }
     public function dangnhapkh(Request $request)

    {
        $email=$request->taikhoan;
        $matkhau=md5($request->matkhau);
        $result=DB::table('khachhang')->where('email',$email)->where('matkhau',$matkhau)->first();


        if($result){
            Session::put('khachhang_id',$result->khachhang_id);
        return redirect::to('/thanh-toan');
         }else
         {
             return redirect::to('/lo-gin');
         }

    }

    public function logout()
    {
        Session::flush();
        return redirect::to('/lo-gin');
    }
}
