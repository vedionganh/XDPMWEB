<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test</title>
    <link rel="stylesheet" href="{{asset('public/frontend/css/style.css')}}">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
    rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style type="text/css" media="screen">
        form.example input[type=text] {
          padding: 10px;
          font-size: 17px;
          border: 1px solid grey;
          float: left;
          width: 80%;
          background: #f1f1f1;
      }

      /* Style the submit button */
      form.example button {
          float: left;
          width: 20%;
          padding: 10px;
          background: #2196F3;
          color: white;
          font-size: 17px;
          border: 1px solid grey;
          border-left: none; /* Prevent double borders */
          cursor: pointer;
      }

      form.example button:hover {
          background: #0b7dda;
      }

      /* Clear floats */
      form.example::after {
          content: "";
          clear: both;
          display: table;
      }

  </style>
</head>

<body>

    <div class="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <a href="{{URL::to('/trang-chu')}}"><img src="{{asset('public/frontend/images/logo.png')}}" width="125px"></a>
                </div>
                <nav>
                    <ul id="MenuItems">
                        <li><a href="{{URL::to('/trang-chu')}}">Trang chủ</a></li>

                        <li><a href="">Dịch vụ</a></li>
                        <li><a href="">Liên hệ</a></li>
                        <?php
                        $id_kh=Session::get('khachhang_id');
                        if($id_kh!=NULL){

                         ?>
                         <li><a href="{{URL::to('/thanh-toan')}}">Thanh toán</a></li>
                         <?php
                     }else{

                      ?>
                        <li><a href="{{URL::to('/lo-gin')}}">Thanh toán</a></li>
                      <?php } ?>


                        <?php
                        $id_kh=Session::get('khachhang_id');
                        if($id_kh!=NULL){

                         ?>
                         <li><a href="{{URL::to('log-out')}}">Đăng xuất</a></li>
                         <?php
                     }else{

                      ?>
                       <li><a href="{{URL::to('/lo-gin')}}">Tài khoản</a></li>
                      <?php } ?>
                    </ul>
                </nav>
                <a href="{{URL::to('hien-thi')}}"><img src="{{asset('public/frontend/images/cart.png')}}" width="30px" height="30px"></a>
                <img src="{{asset('public/frontend/images/menu.png')}}" class="menu-icon"
                onclick="menutoggle()">
            </div>
            <div class="row">
                <div class="col-2">
                    <h1>Give Your Workout<br> A New Style!</h1>
                    <p>Success ins't always about greatness. It's about
                        consistency. Consistent <br>hard work gains success. Greatness
                    will come. </p>
                    <a href="" class="btn">Explore Now &#8594;</a>
                </div>
                <div class="col-2">
                    <img src="{{asset('public/frontend/images/image1.png')}}">
                </div>
            </div>
        </div>
    </div>

    <!-- ------------- featured categorries ---------------- -->
    <div class="categories">
      @yield('discount')

    </div>
    <!-- ------------- featured products ---------------- -->
    <div class="small-container">

        @yield('content')
        {{-- ================================================================================== --}}

    </div>
    {{-- ---------------------------------------------------------------- --}}
    <div class="small-container">
         @yield('all')
    </div>
    <!-- ------------ offer -------------- -->

         @yield('the-end')


    <!-- ------------ testimonial -------------- -->

    <!-- ------------------- brands --------------------- -->
    <div class="brands">
        <div class="small-container">
            <div class="row">
                <div class="col-5">
                    <img src="{{asset('public/frontend/images/logo-godrej.png')}}">
                </div>
                <div class="col-5">
                    <img src="{{asset('public/frontend/images/logo-oppo.png')}}">
                </div>
                <div class="col-5">
                    <img src="{{asset('public/frontend/images/logo-coca-cola.png')}}">
                </div>
                <div class="col-5">
                    <img src="{{asset('public/frontend/images/logo-paypal.png')}}">
                </div>
                <div class="col-5">
                    <img src="{{asset('public/frontend/images/logo-philips.png')}}">
                </div>
            </div>
        </div>
    </div>

    <!-- ------------footer----------- -->

    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col-1">
                    <h3>Download Our App</h3>
                    <p>Download App for Android and ios mobile phone</p>
                    <div class="app-logo">
                        <img src="{{asset('public/frontend/images/play-store.png')}}">
                        <img src="{{asset('public/frontend/images/app-store.png')}}">
                    </div>
                </div>
                <div class="footer-col-2">
                    <img src="{{asset('public/frontend/images/logo-white.png')}}">
                    <p>Our Purpose Is To Sustainably Make the Pleasure and
                    Benefits of Sports Accessible to the Many</p>
                </div>
                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                    <ul>
                        <li>Coupons</li>
                        <li>Blog Post</li>
                        <li>Return Policy</li>
                        <li>Join Affiliate</li>
                    </ul>
                </div>
                <div class="footer-col-4">
                    <h3>Follow us</h3>
                    <ul>
                        <li>Facebook</li>
                        <li>Twitter</li>
                        <li>Instagram</li>
                        <li>Youtube </li>
                    </ul>
                </div>
            </div>
            <hr>
            <p class="Copyright">Copyright 2020 - By QuocHuy</p>
        </div>
    </div>
    <!-- ------------------- js for toggle menu-------------- -->
    <script>
        var MenuItems = document.getElementById("MenuItems");

        MenuItems.style.maxHeight = "0px";

        function menutoggle(){
            if(MenuItems.style.maxHeight == "0px")
            {
                MenuItems.style.maxHeight = "200px";
            }
            else
            {
                MenuItems.style.maxHeight = "0px";
            }
        }

    </script>
</body>
</html>
