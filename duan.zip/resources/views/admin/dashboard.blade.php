@extends('admin_welcome')
@section('admin_content')
<h3>Trang quản trị</h3>
@endsection
